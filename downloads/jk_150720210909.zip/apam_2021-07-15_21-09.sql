#
# TABLE STRUCTURE FOR: apartments
#

DROP TABLE IF EXISTS apartments;

CREATE TABLE `apartments` (
  `apartment_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `floors` varchar(100) NOT NULL,
  `description` varchar(300) NOT NULL,
  `location` varchar(500) NOT NULL,
  `agent_id` int(11) NOT NULL,
  `date_added` int(11) NOT NULL,
  `delete_flag` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`apartment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO apartments (`apartment_id`, `name`, `floors`, `description`, `location`, `agent_id`, `date_added`, `delete_flag`) VALUES ('1', 'Mtungo Flats', '30', 'It has a swimming pool. Very good climate.', 'Nakuru', '66', '1566470127', '0');
INSERT INTO apartments (`apartment_id`, `name`, `floors`, `description`, `location`, `agent_id`, `date_added`, `delete_flag`) VALUES ('2', 'Mlimani Flats', '12', 'In Kangundo road near Kamulu.', 'Nairobi', '66', '1565184664', '0');
INSERT INTO apartments (`apartment_id`, `name`, `floors`, `description`, `location`, `agent_id`, `date_added`, `delete_flag`) VALUES ('3', 'Kamba Flats', '', 'Machakos town apposite Peter Mulei Wholesale building', 'Machakos', '66', '1623591561', '0');
INSERT INTO apartments (`apartment_id`, `name`, `floors`, `description`, `location`, `agent_id`, `date_added`, `delete_flag`) VALUES ('4', 'Felister\'s Flats', '90', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. \n', 'Mombasa', '66', '1565340554', '0');
INSERT INTO apartments (`apartment_id`, `name`, `floors`, `description`, `location`, `agent_id`, `date_added`, `delete_flag`) VALUES ('5', 'Queens Hostel', '7', 'Located a long machakos university highway', 'Machakos', '66', '1626371243', '0');


#
# TABLE STRUCTURE FOR: app_config
#

DROP TABLE IF EXISTS app_config;

CREATE TABLE `app_config` (
  `key` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO app_config (`key`, `value`) VALUES ('address', 'P.o Box 2345-90100  \\n Machakos');
INSERT INTO app_config (`key`, `value`) VALUES ('company', 'Queen\'s Hostel');
INSERT INTO app_config (`key`, `value`) VALUES ('currency_side', '0');
INSERT INTO app_config (`key`, `value`) VALUES ('currency_symbol', 'ksh.');
INSERT INTO app_config (`key`, `value`) VALUES ('email', 'info@apam.com');
INSERT INTO app_config (`key`, `value`) VALUES ('expense_categories', '[\"Dstv\",\"Food\",\"Internet\",\"Water\",\"Salary\"]');
INSERT INTO app_config (`key`, `value`) VALUES ('fax', '0');
INSERT INTO app_config (`key`, `value`) VALUES ('language', 'en');
INSERT INTO app_config (`key`, `value`) VALUES ('logo', 'o_1falllqq21hmbnrmol1nn919ba7.JPG');
INSERT INTO app_config (`key`, `value`) VALUES ('phone', '+25480737883');
INSERT INTO app_config (`key`, `value`) VALUES ('timezone', 'Africa/Nairobi');
INSERT INTO app_config (`key`, `value`) VALUES ('website', 'https://www.apam.com');


#
# TABLE STRUCTURE FOR: attachments
#

DROP TABLE IF EXISTS attachments;

CREATE TABLE `attachments` (
  `attachment_id` int(11) NOT NULL AUTO_INCREMENT,
  `loan_id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `filename` varchar(100) NOT NULL,
  `descriptions` varchar(100) NOT NULL,
  `session_id` varchar(100) NOT NULL,
  PRIMARY KEY (`attachment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO attachments (`attachment_id`, `loan_id`, `tenant_id`, `filename`, `descriptions`, `session_id`) VALUES ('1', '0', '0', 'o_1av647e1p1q191c5rk5hdrfkc47.jpg', '', '1');


#
# TABLE STRUCTURE FOR: expenses
#

DROP TABLE IF EXISTS expenses;

CREATE TABLE `expenses` (
  `expense_id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL DEFAULT 'others',
  `description` text NOT NULL,
  `amount` int(11) NOT NULL,
  `added_by` int(11) NOT NULL,
  `date` date NOT NULL,
  `delete_flag` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`expense_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO expenses (`expense_id`, `category`, `description`, `amount`, `added_by`, `date`, `delete_flag`) VALUES ('1', 'Water', 'Hello', '2000', '66', '2019-08-22', '0');
INSERT INTO expenses (`expense_id`, `category`, `description`, `amount`, `added_by`, `date`, `delete_flag`) VALUES ('2', 'Water', 'Borehole at Felisters apartments', '200000', '66', '2019-08-27', '0');
INSERT INTO expenses (`expense_id`, `category`, `description`, `amount`, `added_by`, `date`, `delete_flag`) VALUES ('3', 'Dstv', 'Payment for dstv for mohamud Ali', '5000', '66', '2021-07-15', '0');


#
# TABLE STRUCTURE FOR: houses
#

DROP TABLE IF EXISTS houses;

CREATE TABLE `houses` (
  `house_id` int(11) NOT NULL AUTO_INCREMENT,
  `apartment_id` int(11) NOT NULL,
  `house_no` varchar(100) NOT NULL,
  `house_type` varchar(100) NOT NULL,
  `features` text NOT NULL,
  `description` text NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'vacant',
  `rent` varchar(100) NOT NULL,
  PRIMARY KEY (`house_id`),
  UNIQUE KEY `house_no` (`house_no`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('1', '1', 'M001', '3 Bedroom', '[\"wifi\",\"hot_shower\",\"dstv\"]', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum, ratione atque. Voluptate sunt deserunt harum quos velit, vero dolorum, nobis natus voluptatem nisi iure corporis fugiat illum inventore eius quas.\n', 'Under maintenance', '16,000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('2', '1', 'M002', '1 Bedroom', '[\"wifi\",\"dstv\"]', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum, ratione atque. Voluptate sunt deserunt harum quos velit, vero dolorum, nobis natus voluptatem nisi iure corporis fugiat illum inventore eius quas.\n', 'Occupied', '12000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('3', '1', 'M003', '3 Bedroom', '[\"hot_shower\"]', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum, ratione atque. Voluptate sunt deserunt harum quos velit, vero dolorum, nobis natus voluptatem nisi iure corporis fugiat illum inventore eius quas.\n', 'Occupied', '13000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('4', '1', 'M004', '4 Bedroom', '[\"hot_shower\",\"dstv\"]', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum, ratione atque. Voluptate sunt deserunt harum quos velit, vero dolorum, nobis natus voluptatem nisi iure corporis fugiat illum inventore eius quas.\n', 'Out of order', '20000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('5', '2', 'ML001', 'Double Room', '[\"wifi\",\"hot_shower\",\"dstv\"]', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum, ratione atque. Voluptate sunt deserunt harum quos velit, vero dolorum, nobis natus voluptatem nisi iure corporis fugiat illum inventore eius quas.\n', 'Occupied', '14,000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('6', '2', 'ML002', 'Double Room', '[\"wifi\",\"hot_shower\",\"dstv\"]', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum, ratione atque. Voluptate sunt deserunt harum quos velit, vero dolorum, nobis natus voluptatem nisi iure corporis fugiat illum inventore eius quas.\n', 'Occupied', '10000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('7', '2', 'ML003', 'Singe Room', '[\"wifi\",\"hot_shower\"]', 'Lorem ipsum', 'Out of order', '3000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('17', '2', 'ML004', 'Singe Room', '[\"dstv\"]', 'HELLO', 'Vacant', '2000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('18', '2', 'ML005', 'Bedsitter', '[\"hot_shower\",\"dstv\"]', 'HELLO', 'occupied', '2000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('19', '2', 'ML006', 'Bedsitter', '[\"dstv\"]', 'HELLO', 'Vacant', '2000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('8', '3', 'K001', '2 Bedroom', '[\"wifi\",\"hot_shower\",\"dstv\"]', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum, ratione atque. Voluptate sunt deserunt harum quos velit, vero dolorum, nobis natus voluptatem nisi iure corporis fugiat illum inventore eius quas.\n', 'Out of order', '3000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('9', '3', 'K002', '5 Bedroom', '[\"wifi\",\"hot_shower\"]', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum, ratione atque. Voluptate sunt deserunt harum quos velit, vero dolorum, nobis natus voluptatem nisi iure corporis fugiat illum inventore eius quas.\n', 'Occupied', '3000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('10', '3', 'K003', '4 Bedroom', '[\"hot_shower\",\"dstv\"]', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum, ratione atque. Voluptate sunt deserunt harum quos velit, vero dolorum, nobis natus voluptatem nisi iure corporis fugiat illum inventore eius quas.\n', 'Occupied', '3000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('12', '1', 'MLOO5', '2 Bedroom', '[\"wifi\",\"hot_shower\"]', 'BLAHBAH', 'vacant', '7000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('13', '4', 'F001', '2 Bedroom', '[\"wifi\",\"water\"]', 'I am felistus', 'Vacant', '15,000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('14', '4', 'F002', '2 Bedroom', '[\"wifi\",\"water\"]', 'I am felistus', 'Vacant', '20,000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('20', '2', 'ML007', 'Singe Room', '[\"hot_shower\"]', 'HELO', 'vacant', '2000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('21', '1', 'ML010', '3 Bedroom', '[\"wifi\",\"hot_shower\",\"dstv\"]', 'NEW', 'Occupied', '20000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('22', '1', 'ML011', 'Singe Room', '[\"wifi\",\"dstv\",\"water\"]', 'cool', 'Vacant', '20000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('23', '3', 'K004', '2 Bedroom', '[\"wifi\",\"hot_shower\",\"water\"]', 'I have nothing', 'Vacant', '20000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('24', '5', 'Q001', 'Bedsitter', '[\"wifi\",\"water\"]', 'In good condition', 'occupied', '7000');
INSERT INTO houses (`house_id`, `apartment_id`, `house_no`, `house_type`, `features`, `description`, `status`, `rent`) VALUES ('25', '5', 'Q002', '1 Bedroom', '[\"wifi\",\"hot_shower\",\"dstv\",\"water\"]', 'In good condition', 'Vacant', '10000');


#
# TABLE STRUCTURE FOR: letters
#

DROP TABLE IF EXISTS letters;

CREATE TABLE `letters` (
  `letter_id` int(11) NOT NULL AUTO_INCREMENT,
  `address` text NOT NULL,
  `subject` varchar(100) NOT NULL,
  `created_by` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `delete_flag` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`letter_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO letters (`letter_id`, `address`, `subject`, `created_by`, `message`, `date_created`, `delete_flag`) VALUES ('8', 'JOHN', 'Hello', '66   ', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\ncillum dolore eu fugiat nulla pariatur. ', '2019-08-13 00:00:00', '0');
INSERT INTO letters (`letter_id`, `address`, `subject`, `created_by`, `message`, `date_created`, `delete_flag`) VALUES ('10', 'mutua', 'Hello', '66 ', 'gfdsvsdvsdvsv', '2019-11-03 00:00:00', '0');
INSERT INTO letters (`letter_id`, `address`, `subject`, `created_by`, `message`, `date_created`, `delete_flag`) VALUES ('11', 'Mr ken', 'vacate', '66 ', 'Vacate because of this reason', '2019-12-29 00:00:00', '0');
INSERT INTO letters (`letter_id`, `address`, `subject`, `created_by`, `message`, `date_created`, `delete_flag`) VALUES ('9', 'john,', 'Hello', '66   ', 'hello hello hello hello helloo', '2019-08-20 00:00:00', '0');
INSERT INTO letters (`letter_id`, `address`, `subject`, `created_by`, `message`, `date_created`, `delete_flag`) VALUES ('12', 'Mr Kamau', 'vacate', '66 ', 'Vacate right now', '2020-02-25 00:00:00', '0');
INSERT INTO letters (`letter_id`, `address`, `subject`, `created_by`, `message`, `date_created`, `delete_flag`) VALUES ('13', 'Mohamud Ali', 'You should pay rent', '66  ', 'You should vacate immediately because you have this and this which is illegal.', '2021-07-15 00:00:00', '0');


#
# TABLE STRUCTURE FOR: modules
#

DROP TABLE IF EXISTS modules;

CREATE TABLE `modules` (
  `module_id` varchar(255) NOT NULL,
  `controller` varchar(50) NOT NULL,
  `sort` int(10) NOT NULL,
  `icons` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`module_id`),
  UNIQUE KEY `name_lang_key` (`controller`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO modules (`module_id`, `controller`, `sort`, `icons`, `is_active`) VALUES ('apartments', 'apartments', '20', '<i class=\"fa fa-briefcase\" style=\"font-size: 50px;\"></i>', '1');
INSERT INTO modules (`module_id`, `controller`, `sort`, `icons`, `is_active`) VALUES ('delayed payments', 'overdues', '40', '<i class=\"fa fa-bomb\" style=\"font-size: 50px;\"></i>', '1');
INSERT INTO modules (`module_id`, `controller`, `sort`, `icons`, `is_active`) VALUES ('expenses', 'expenses', '67', '<i class=\"fa fa-minus-circle\" style=\"font-size: 50px;\"></i>', '1');
INSERT INTO modules (`module_id`, `controller`, `sort`, `icons`, `is_active`) VALUES ('letters', 'letters', '65', '<i class=\"fa fa-envelope\" style=\"font-size: 50px;\"></i>', '1');
INSERT INTO modules (`module_id`, `controller`, `sort`, `icons`, `is_active`) VALUES ('payments', 'payments', '30', '<i class=\"fa fa-exchange\" style=\"font-size: 50px;\"></i>', '1');
INSERT INTO modules (`module_id`, `controller`, `sort`, `icons`, `is_active`) VALUES ('Settings', 'config', '70', '<i class=\"fa fa-cogs\" style=\"font-size: 50px\"></i>', '1');
INSERT INTO modules (`module_id`, `controller`, `sort`, `icons`, `is_active`) VALUES ('staff', 'staffs', '60', '<i class=\"fa fa-users\" style=\"font-size: 50px;\"></i>', '1');
INSERT INTO modules (`module_id`, `controller`, `sort`, `icons`, `is_active`) VALUES ('tenants', 'tenants', '10', '<i class=\"fa fa-smile-o\" style=\"font-size: 50px;\"></i>', '1');


#
# TABLE STRUCTURE FOR: payments
#

DROP TABLE IF EXISTS payments;

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `house_id` int(11) NOT NULL,
  `tenant_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(20) NOT NULL,
  `breakdown` text NOT NULL,
  `paid_by` varchar(100) NOT NULL,
  `paid_for` varchar(100) NOT NULL,
  `teller_id` int(11) NOT NULL,
  `date_paid` date NOT NULL,
  `date_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `remarks` varchar(2000) NOT NULL,
  `delete_flag` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`payment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO payments (`payment_id`, `house_id`, `tenant_id`, `amount`, `payment_method`, `breakdown`, `paid_by`, `paid_for`, `teller_id`, `date_paid`, `date_modified`, `remarks`, `delete_flag`) VALUES ('1', '7', '310', '3000.00', 'cash', '{\"deposit\":\"1500\",\"rent\":\"1500\"}', 'mutiso', '{\"month\":\"3\",\"year\":\" 2019\"}', '66', '2019-08-19', '2019-08-22 00:00:00', 'Good', '0');
INSERT INTO payments (`payment_id`, `house_id`, `tenant_id`, `amount`, `payment_method`, `breakdown`, `paid_by`, `paid_for`, `teller_id`, `date_paid`, `date_modified`, `remarks`, `delete_flag`) VALUES ('2', '14', '311', '30000.00', 'cash', '{\"deposit\":\"10000\",\"rent\":\"20000\"}', 'john', '{\"month\":\"4\",\"year\":\" 2021\"}', '66', '2019-08-18', '2019-08-22 00:00:00', 'better', '0');
INSERT INTO payments (`payment_id`, `house_id`, `tenant_id`, `amount`, `payment_method`, `breakdown`, `paid_by`, `paid_for`, `teller_id`, `date_paid`, `date_modified`, `remarks`, `delete_flag`) VALUES ('3', '18', '314', '2000.00', 'cash', '{\"deposit\":\"1000\",\"rent\":\"1000\"}', 'Sean', '{\"month\":\"5\",\"year\":\" 2020\"}', '66', '2019-08-20', '2019-08-22 00:00:00', 'good', '0');
INSERT INTO payments (`payment_id`, `house_id`, `tenant_id`, `amount`, `payment_method`, `breakdown`, `paid_by`, `paid_for`, `teller_id`, `date_paid`, `date_modified`, `remarks`, `delete_flag`) VALUES ('4', '12', '321', '14000.00', 'cash', '{\"deposit\":\"7000\",\"rent\":\"7000\"}', 'Kelvin', '{\"month\":\"8\",\"year\":\" 2019\"}', '320', '2019-08-22', '2019-08-22 13:29:02', 'good', '0');
INSERT INTO payments (`payment_id`, `house_id`, `tenant_id`, `amount`, `payment_method`, `breakdown`, `paid_by`, `paid_for`, `teller_id`, `date_paid`, `date_modified`, `remarks`, `delete_flag`) VALUES ('5', '7', '310', '3000.00', 'cash', '{\"deposit\":\"1500\",\"rent\":\"1500\"}', 'john', '{\"month\":\"8\",\"year\":\" 2019\"}', '320', '2019-08-23', '2019-08-23 13:19:18', 'good', '0');
INSERT INTO payments (`payment_id`, `house_id`, `tenant_id`, `amount`, `payment_method`, `breakdown`, `paid_by`, `paid_for`, `teller_id`, `date_paid`, `date_modified`, `remarks`, `delete_flag`) VALUES ('6', '12', '312', '7000.00', 'cash', '{\"deposit\":\"3500\",\"rent\":\"3500\"}', 'Sean', '{\"month\":\"8\",\"year\":\" 2019\"}', '320', '2019-08-23', '2019-08-23 13:29:19', 'good', '0');
INSERT INTO payments (`payment_id`, `house_id`, `tenant_id`, `amount`, `payment_method`, `breakdown`, `paid_by`, `paid_for`, `teller_id`, `date_paid`, `date_modified`, `remarks`, `delete_flag`) VALUES ('7', '20', '313', '2000.00', 'cash', '{\"deposit\":\"1000\",\"rent\":\"1000\"}', 'Sean', '{\"month\":\"8\",\"year\":\" 2019\"}', '320', '2019-08-23', '2019-08-23 13:34:41', 'good', '0');
INSERT INTO payments (`payment_id`, `house_id`, `tenant_id`, `amount`, `payment_method`, `breakdown`, `paid_by`, `paid_for`, `teller_id`, `date_paid`, `date_modified`, `remarks`, `delete_flag`) VALUES ('8', '20', '315', '2000.00', 'cash', '{\"deposit\":\"1000\",\"rent\":\"1000\"}', 'Ken', '{\"month\":\"8\",\"year\":\" 2019\"}', '320', '2019-08-23', '2019-08-23 13:35:26', 'good', '0');
INSERT INTO payments (`payment_id`, `house_id`, `tenant_id`, `amount`, `payment_method`, `breakdown`, `paid_by`, `paid_for`, `teller_id`, `date_paid`, `date_modified`, `remarks`, `delete_flag`) VALUES ('9', '20', '315', '1500.00', 'cash', '{\"deposit\":\"0\",\"rent\":\"1500\"}', 'Ken', '{\"month\":\"8\",\"year\":\" 2020\"}', '66', '2019-08-26', '2020-02-27 00:00:00', 'not good', '0');
INSERT INTO payments (`payment_id`, `house_id`, `tenant_id`, `amount`, `payment_method`, `breakdown`, `paid_by`, `paid_for`, `teller_id`, `date_paid`, `date_modified`, `remarks`, `delete_flag`) VALUES ('10', '7', '310', '1000.00', 'cash', '{\"deposit\":\"0\",\"rent\":\"1000\"}', 'john', '{\"month\":\"8\",\"year\":\" 2019\"}', '66', '2019-08-26', '2019-08-26 15:15:14', 'not good', '0');
INSERT INTO payments (`payment_id`, `house_id`, `tenant_id`, `amount`, `payment_method`, `breakdown`, `paid_by`, `paid_for`, `teller_id`, `date_paid`, `date_modified`, `remarks`, `delete_flag`) VALUES ('11', '10', '326', '4000.00', 'mpesa', '{\"deposit\":\"1000\",\"rent\":\"3000\"}', 'Dante', '{\"month\":\"7\",\"year\":\" 2021\"}', '66', '2021-06-13', '2021-06-13 16:46:43', 'paid in full', '0');
INSERT INTO payments (`payment_id`, `house_id`, `tenant_id`, `amount`, `payment_method`, `breakdown`, `paid_by`, `paid_for`, `teller_id`, `date_paid`, `date_modified`, `remarks`, `delete_flag`) VALUES ('12', '24', '327', '10000.00', 'bank_transfer', '{\"deposit\":\"7000\",\"rent\":\"3000\"}', 'Mohamud', '{\"month\":\"8\",\"year\":\" 2021\"}', '66', '2021-07-15', '2021-07-15 00:00:00', 'not paid in full', '0');


#
# TABLE STRUCTURE FOR: people
#

DROP TABLE IF EXISTS people;

CREATE TABLE `people` (
  `person_id` int(10) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `photo_url` varchar(255) DEFAULT NULL,
  `id_number` int(11) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `home_address` varchar(255) NOT NULL,
  PRIMARY KEY (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=328 DEFAULT CHARSET=utf8;

INSERT INTO people (`person_id`, `first_name`, `last_name`, `photo_url`, `id_number`, `phone_number`, `email`, `home_address`) VALUES ('66', 'admin', 'apam', NULL, '12345678', '0712345768', 'admin@apam.com', 'Nairobi');
INSERT INTO people (`person_id`, `first_name`, `last_name`, `photo_url`, `id_number`, `phone_number`, `email`, `home_address`) VALUES ('310', 'john', 'jhbsxj', NULL, '12344554', '0704801487', 'test@gaml.com', 'mwala');
INSERT INTO people (`person_id`, `first_name`, `last_name`, `photo_url`, `id_number`, `phone_number`, `email`, `home_address`) VALUES ('311', 'john', 'jhbsxj', NULL, '12344554', '0704801487', 'tetst@gaml.com', 'mwala');
INSERT INTO people (`person_id`, `first_name`, `last_name`, `photo_url`, `id_number`, `phone_number`, `email`, `home_address`) VALUES ('312', 'Sean ', 'Baraka', NULL, '12121212', '0706801480', 'seanb@gmail.com', 'Mlimani');
INSERT INTO people (`person_id`, `first_name`, `last_name`, `photo_url`, `id_number`, `phone_number`, `email`, `home_address`) VALUES ('313', 'Sean ', 'Hello', NULL, '12121212', '0704801487', 'test2@gaml.com', 'Mlimani');
INSERT INTO people (`person_id`, `first_name`, `last_name`, `photo_url`, `id_number`, `phone_number`, `email`, `home_address`) VALUES ('314', 'Sean ', 'Hello', NULL, '12121212', '0704801487', 'test3@gaml.com', 'Mlimani');
INSERT INTO people (`person_id`, `first_name`, `last_name`, `photo_url`, `id_number`, `phone_number`, `email`, `home_address`) VALUES ('315', 'Ken', 'Muthama', NULL, '12344554', '0789898989', 'mx@gmail.com', 'Mlimani');
INSERT INTO people (`person_id`, `first_name`, `last_name`, `photo_url`, `id_number`, `phone_number`, `email`, `home_address`) VALUES ('317', 'Kelvin', 'Mboto', NULL, '123456781', '0712345678', 'vinte@gmail.com', 'Mitaboni');
INSERT INTO people (`person_id`, `first_name`, `last_name`, `photo_url`, `id_number`, `phone_number`, `email`, `home_address`) VALUES ('319', 'Baraka', 'Sean', NULL, '898989898', '0789898989', 'bbaraka@gmail.com', 'Mlimani');
INSERT INTO people (`person_id`, `first_name`, `last_name`, `photo_url`, `id_number`, `phone_number`, `email`, `home_address`) VALUES ('320', 'John', 'Malindi', NULL, '34289777', '0708112112', 'malindi.wambua@yahoo.com', 'mwala');
INSERT INTO people (`person_id`, `first_name`, `last_name`, `photo_url`, `id_number`, `phone_number`, `email`, `home_address`) VALUES ('321', 'Kelvin', 'Mboto', NULL, '98765432', '0701995445', 'mboto@gmail.com', 'Mitaboni');
INSERT INTO people (`person_id`, `first_name`, `last_name`, `photo_url`, `id_number`, `phone_number`, `email`, `home_address`) VALUES ('322', 'Sean ', 'Baraka', NULL, '98765431', '0789898989', 'seanbaraka@gmail.com', 'Mombasani');
INSERT INTO people (`person_id`, `first_name`, `last_name`, `photo_url`, `id_number`, `phone_number`, `email`, `home_address`) VALUES ('323', 'Festus', 'Festus', NULL, '1234523', '0790909090', 'kisa@gmail.com', 'Uasin ');
INSERT INTO people (`person_id`, `first_name`, `last_name`, `photo_url`, `id_number`, `phone_number`, `email`, `home_address`) VALUES ('324', 'Diana', 'Kinyua', NULL, '78787878', '079999999', 'dayo@gmail.com', 'Nyandarua');
INSERT INTO people (`person_id`, `first_name`, `last_name`, `photo_url`, `id_number`, `phone_number`, `email`, `home_address`) VALUES ('325', 'mary', 'mwongeli', NULL, '45454545', '070808080', 'ms@gmail.com', 'nyandarua');
INSERT INTO people (`person_id`, `first_name`, `last_name`, `photo_url`, `id_number`, `phone_number`, `email`, `home_address`) VALUES ('326', 'Dante', 'Wambua', NULL, '347889123', '072389898989', 'dante@gmail.com', 'Machakos');
INSERT INTO people (`person_id`, `first_name`, `last_name`, `photo_url`, `id_number`, `phone_number`, `email`, `home_address`) VALUES ('327', 'Mohamud', 'Ali', NULL, '798738383', '254704801788', 'mohamud@gmail.com', 'Machakos');


#
# TABLE STRUCTURE FOR: sessions
#

DROP TABLE IF EXISTS sessions;

CREATE TABLE `sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('01d3a195b3542c8fd8a8f04b3da547bd', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564133962', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('020de1ccefb592258395f0cbd0671e5d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1565342516', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('02e419f06963281758ae87df143fa961', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565789897', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('0310100f55bf6c945cd280f7c3aa6f68', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1566817738', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('03148f40cd3225ffc71134441056fead', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564409810', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('037e792b52416ffb100fc188d5078745', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '1568984795', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('046393544e5f3301a3fbc90fc42c8f4d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564136017', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('049d6f910d8e4925493294887435c6a0', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', '1582821459', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('051932bc67c50616fc52bf3f787fb8aa', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565789840', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('0558b5161d2baf0ccae28c241c517367', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0', '1565017406', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('07166416c70f0b9a370f328751fcffb0', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36', '1605604249', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('0780012e8bdb7ce610c538823c2230a4', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36', '1574135831', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('07d7ff040c96e759b8234e9bf9979799', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '1579194007', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('080e0387eac3c8ea2465a4da558e3a0d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '1568964580', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('089ff26a54d56baf29e620835b10a845', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564133156', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('09b7ee2a45c151c3eab3db5ec3773b3a', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565789527', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('09ca2a90adf8e0afc94660c2cb7c5e33', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564648736', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('0aa74c3e4ed3bbaf2ace1edea14de578', '::1', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1563928758', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('0b8124a8341e0ce52bd7c4dda52470ec', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36', '1564067971', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('0cda1efccff2f00205dc39e678640582', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '1579607731', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('0cebc43c50a3a32beb4bdb32a1ccbb90', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564129811', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('0fb87a62c4e9e42457d65181797e2f26', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564492536', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('10b9eddc9d1bacff253086ce15031870', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '1568869428', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('114ed1acf792a2d3373b783216cd8752', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36', '1605516726', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('1173c23caccf1b059fccd534545dab8d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1565077877', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('117c8c63dc4e8c2fc9baddc36184744d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.67 Safari/537.36', '1606306675', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('11821d32e7844f4a948e2ba1dea5fb36', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1565028912', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('11b93686036222bb338df7024cc3b2ab', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1565077877', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('11f9a9227c2a2b6ab01a5f36294a9861', '192.168.100.30', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '1585835366', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('1386b030056f97d8fa7dcc03ed65bdc5', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565777458', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('13889b4a764a9c061955e829f97ed30b', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564151621', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('14f76bed1102de01480ad19478c4799f', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36', '1605263616', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('1507340320cd865f301a2bb789bfd879', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1566817696', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('16cdba2b20e146d59bb20389da9ed8f9', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1566721193', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('17751f8c2b51e0d7e0f6b082e116b2ac', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36', '1619883427', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('17a0ce7c1088aa7556f79e22a7b9d6f1', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36', '1574135831', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('18bc4f9c6373d5d12b285e600d715003', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564644851', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('1ac8224271ba23bad453f663ab1b2c21', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1566830067', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('1af1266418738e14600f0d7e4925079c', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564139548', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('1caddf329f9d7a53e39d294a5546fe51', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Safari/537.36', '1613555266', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('1fae499a52c0224a3fb04b550eb54745', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564393743', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('1fc254a5da83f596d5339ff550b9d328', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1566817749', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('243aa4c062791121c568769716812ac9', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '1579162338', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('244aba0e563b324baf8bb26212f4415d', '::1', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1563918860', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('25431fb8a6a562e628c2af04ee393815', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564580748', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('269eb2a034427f8ef7834448a3d3c0b8', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36', '1626255337', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('270f36bd72773ef1ddf85740916e5ac3', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564138015', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('27cd552fefbffb4db6f87da161644525', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', '1584015690', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('293236a7f5d2808e6bedde31b6aca7e5', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1566114939', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('29377cafa6f6d70604faed5cb0599a72', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564996716', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('2a237c06aa25ead8f1bc444ba06f3eed', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564150190', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('2d66cedb4c3520d35c5c1f8b69091656', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564136017', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('2ec28581508cfb7314004615d1213144', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1566646448', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:3:\"320\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('31de1f27ad017c1e24414cad43f18230', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1565342862', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('3203484a99e03cb009923a73d819cfcc', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1565175119', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('320bb11e959e8e500a0f5692ed42f4ea', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564141185', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('34c5d1018b9486b95d5fbbc8e49a461c', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564393745', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('360eaea38ac5d133dfe142e54e428a37', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', '1569411933', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('36db46e1a3eaac12fcaf01cabd6ffc05', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564407995', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('371a7210f0b61778104ab47516900a45', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '1568869146', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('373e64c735a880c41c25f82fb3a9dbb0', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564136017', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('395fe63c25d2350af68d776bc5f560f7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', '1582617879', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('3980a4b4eac1271ad28f6fb1212de942', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564491528', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('3aaab7d0ec68568ed982e8c02a8e81c6', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564584318', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('3c5d2b998dba5733fced1bbde3ad5fec', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564128158', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('3db1019397e7b691c9707fc8664c0bc8', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.72 Safari/537.36', '1618911215', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('3dc1a6c4904e42f67950c4717da5e364', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565789881', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('3e8c9e3c624e7c16855d7cfb3e2f9b4d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565784259', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('3e9b00cf7c3cd1ca3604fb604082f6fb', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564128159', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('40a7d2f36a304950ddeeb8b48984f059', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36', '1574232818', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('4160259e713a7be69251d9d52fc19dad', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '1579764416', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('41b4904469bdae976747077fd3ba4b19', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564136017', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('42a5a2e344c2b05e70d7e37596b4427f', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '1568389784', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('439d2c8728e7a8071ee871b16796e901', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564150190', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('4475b69823a4c52eab267dcd5d30257f', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565789836', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('448f2f24d4dad2427cd8d8a2a3848734', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '1568800749', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('45d10dbbd7272be18b00863455881948', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '1580900090', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('46b4fcaa2ddaadfb43aae015de9b79d1', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36', '1574136004', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('4771b3e5a9788a3e446bdbd0e3e4943d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565783457', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('48588cd4b73fb99488a1f1fe597888c1', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1566817708', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('486733b517b707e7c973438f1c52ce3a', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565789947', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('4945d4acab177923eaf360492569d4f2', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36', '1605595941', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('4960a9ff43e9403ba0f02741d0164321', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36', '1605531869', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('4af43a9cee78e5cece2327002de3493d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Safari/537.36', '1613555266', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('4b90cb7394e0a741464789eb2a3a371a', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564572616', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('4c5f4e67907e3a74619d020f3a8b5d6a', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565682990', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('4c82c912fe250c6d8627de1c480b3437', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Safari/537.36', '1613555266', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('4e61677f9ffd7531551fc95efd723cc0', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565789576', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('50d7ed78e12188ec10e82955b3ac7e27', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564408976', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('5122c566409bd66e5c573883b7c675e0', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564393750', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('51a4bd5747a2ed6282c3169f8d01cd1e', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564407510', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('51b0293982069b85584e08fc19c15a00', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565783471', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('51e64ee84756b860e23af2feeadb1927', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564582514', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('52b3bdbf9ecffa702613e7640993a2b5', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', '1582006676', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('541d4f513d2c9a6a230d216f3b934bb4', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564407510', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('54b8a05ab6a912986128fe547de7b8ac', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564490659', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('55ce433b7421d7acb4616bb49acd4fdf', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565967361', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('5768b90e73dced150aedf4f0405e02c7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565783457', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('58c5917295e8d6956fde70d98e923a74', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564404388', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('5ab5d6d6f9d813513651a28b42bb1f25', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564133156', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('5b76f3f6a0f3e1ff6b09001f1fc58582', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564580748', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('5bbae230b5afb04de1f124b7647284bd', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', '1581936945', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('5e4b7b71f18ed6fa3506d1e9cf40a22d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', '1581576233', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('6386a3758e811a675935bc606aceebf7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1565077469', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('650583acdcdaf1ed720588c94d7d4cb6', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564478283', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('674f488f83fa09492627aa40145ff086', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0', '1565017258', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('678e9778f761673c54a52743d5178698', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564129626', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('6810a35043922e76cbd58e2f64e5d850', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565966271', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('681752ec26fccda839613f7d5c2e5839', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1566830067', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('6b57c85561e6acb1ca7453160356ab3c', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', '1582565586', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('6bcab9442a69d67a5fd458380844671d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564141357', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('6be0949f9c959e308ee4152bf36f7cf3', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', '1569662362', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('6d552a43e496d2c5d532ee24d1bf0211', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '1606116987', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('6d9f3cae18d921b158c59c92cd597754', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '1568379121', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('6e209ac732c09fe094e25f23c738e7d3', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1565187202', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('704ce962720d3f5be4da11dbbae0b899', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564150116', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('706589f4a5380cdd3f9ee6ef6fcbcd29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '1568874308', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('712903ef58b773a0915a11dc429c5081', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '1568800769', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('7328dc6eb4783a6df1e01591c2d137ef', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36', '1605610679', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('73397b6b0deb2aba7a23cbe5411950ce', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564388467', 'a:2:{s:9:\"person_id\";s:2:\"66\";s:4:\"data\";N;}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('753559c27ebad6d62a7d24d15e3eafd8', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1563982176', 'a:2:{s:9:\"person_id\";s:2:\"66\";s:4:\"data\";N;}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('7725135a89292c3862f4a6cc194b312d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565791124', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('7872f72a724d6142d61b81ce08a363f0', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36', '1623592370', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('79f53520878c70f75fbb835a79e65b74', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.67 Safari/537.36', '1606764325', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('7b0eb319f46fa0e038c851e764596b35', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564139585', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('7d5f71788e02c25f3fd260d336f7fa60', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564133155', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('7f5b8f60a01e2fa7cd110a2d102d70b9', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.67 Safari/537.36', '1606895061', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('7f7ba998ca44c3680d5f34bca0cf09f9', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564133077', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('7fd77fc7886bffafe26763742bf47c6f', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '1568975701', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('803768621a59ae27c98a2e4788569c90', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564150286', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('8128de98eba335a78f3d309febd4959b', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1565342865', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('815490002e97e90729eac3004e404417', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564409211', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('81c0a0a4dd9766105282537b15138833', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564388490', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('828d74d4402ae481a01b2b5ba8dddae7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '1579162333', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('836d8227ef6921d47b5575736fb4b1de', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', '1582616021', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('84ff8818ddf025c4e3e029f23ca5a6ac', '192.168.43.99', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564067972', 'a:3:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";s:4:\"data\";N;}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('851953b68ce3735c1bcb2ff1386454d7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565789751', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('8658757e92bcbe41d6f6c84cabd98f40', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564407510', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('86b75e5f931e804c1581c157f55526e7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', '1569836428', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('876786ee3ca751ca658f3dc8ada2fe3c', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564395365', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('8786ebd0a365adea838d76656bbb264d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1563959268', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('88007201f06b008525422574220e1306', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1565193160', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('88f49bccf5f1747fdcf0fddcdda0e3bb', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '1568398490', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('89068db96a5ebf586cc5561f2f66961e', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Safari/537.36', '1613561387', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('893ad7b563c409c03ff6c40a7cce4a97', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '1605618405', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('8976ead7f133578702145ce5290ec2fc', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '1605618425', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('898b81dd81f5e88a884119a976ca1c10', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', '1582902610', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('8a248d7c77abb2a385713df7dc3157bb', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1565193160', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('8a4d54870cd4e1303b8b966e147dddcf', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '1568655147', 'a:3:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";s:4:\"data\";N;}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('8a8205a785c63babf6ec9e9ad965883a', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36', '1605538862', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('8ae38736ba4d125fe81598b0b736bd2e', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36', '1585311800', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('8bb37612b6714bd3219392a18ccf970f', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1565077878', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('8bd8a2d91c7dc8fb9610bce775bb74d5', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '1569142569', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('8c4b98616e7caefc4b9fc04233bb75d9', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564392017', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('8ca9cbf774c1277f98cdfbb47ddc7338', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565789439', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('8d43ce38887736d8d2eba127a6c29ba6', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564996399', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('8f0c0418d2f82d37ce12dbccf01d5cba', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564753903', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('8f1e15cc63529030fc6c84044f9b8d37', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36', '1624793427', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('9107a611e894081343232f5002d5db69', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.120 Safari/537.36', '1574135628', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('9124d9b9106682fd1bb1e25c8fbfb02d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564150189', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('93aff25d4cee8193fc18228ce618b38f', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36', '1613916867', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('9472a275720e38d6a935e263238004fe', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36', '1605259225', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('94d1734df3067074b6f82832eaeee909', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', '1581936722', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('95997126f01516e4081b7990e37b39aa', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '1568450582', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('9619d956953a6fe9130a64a897e697bd', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564471418', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('972303a668c71cec7a512c59b3389831', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564133962', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('9822bb71efe9b41ceb37006d4f0fdf76', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1566817697', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('9a279a3c089ae23c943b82c19fa6b7d4', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '1568379132', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('9af3b017f600c03a896764bc3c8679ec', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564582514', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('9b4280ca845f3412e9fc5ee6dbf8667d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564407511', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('9cbab01af45557749f7bd6db67c63e9d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '1579086027', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('9ec98d47c72ab160a3dff0f5ca631020', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565789633', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('9f4a5674e33e0d78e842d6650cb7538a', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564407511', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('a0093d38291360a4050905381db91aa3', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1566830067', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('a0dbb27f47ce102a156d7da7d9de1be8', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564395363', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('a1076855cbdbe967d1af8ee59e0caadc', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564133962', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('a3f9dac1632f5f253707740dd6a285b9', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564395364', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('a3faaa385f9abfd9b67ee898d3ec2227', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565950596', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('a4175ecf2c280a9aa75c4a5acea71a30', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '1568975712', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('a4ba9af6994675dadaf440653de7a586', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36', '1605598169', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('a71b506debb83c02cb7fe6293f71efec', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', '1581847502', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('a88f91465b5f28eb90cf1ceb231d56d3', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36', '1613921909', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('ab47796eb2a5fbbe269c044166da1724', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565789674', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('ac724667b793dad5433dbdabf9c79d8b', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '1579080764', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('acc65da68fee8d51b89ff39596218c80', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565789998', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('ad2d601dff81d2dac6e5a900c2a57fe0', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36', '1613932780', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('aecc7b45f4a7a7ab66c0e5df8653c2c9', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564582502', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('af1dc4741069cf4837355f7688c7b6c8', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Safari/537.36', '1613561387', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('b0e2925f4b65a145c3667cac7e601c57', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1566817705', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('b158e0ef5ec638f5de4d73daa2e68acf', '::1', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1563918860', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('b16a36127e4656ee3a8a6c6221c76765', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', '1570024779', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('b1c3c7229d1e3280dedd44fbf8bb804d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', '1582007195', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('b7108a007f35ae40bb9e561880194691', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', '1582821126', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('b88aef3dc167a1ad2dadd0f082331789', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1565077878', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('b8e294c934803351346476251e50c985', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564136793', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('b9305fe8e3109e5429a49ef01abf89dc', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36', '1605260695', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('b9effa16194629ace2a0f6a93f4b6dbb', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1566819163', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('bb51dff65480f9252ad095edcd83a6d2', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36', '1605533085', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('bb64535933d2b53bf48c6fbec2128906', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', '1582006929', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('bd9982336ab59cd77fc0d054f15aa874', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564150294', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('be83dfcbba22fd115f06cc22a9a2539b', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564136997', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('bf3a2d896745b3343f50275e4d9cce01', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565789634', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c017923505b27a5e557343dd8405e0fc', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564648754', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c195178c78fedcb89ca37c6db056d321', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1565176381', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c1c31d610e299eb84c2f1be268195410', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564409481', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c26ec85efe0c15c611dbca581217e122', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36', '1619869680', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c2e22004216fc48167fc3a99e3a6b64e', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564129986', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c3075ae8407e719c3b2eeafd992f2a6e', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1565342857', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c46a6263497c70f3273cb6ad7d8cab12', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564478159', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c46bf605ef1162a1d2bace2481ff5049', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564492113', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c614dfdbebe1b0a18d6276322f0254e1', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36', '1626372547', 'a:3:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";s:4:\"data\";N;}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c77fe3c9346424f02ec482187f051c29', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1568144786', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('c9ebdacc2f60038e7200a996c7b680bc', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565768689', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('cadf50b76be8c3c8f4cbcfb78a31717e', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '1605690979', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('cb446997f837f3fcccb9d9126da009e6', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '1579014150', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('cbdfd2e26a8e782c325b4c2c85f83b0a', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564408586', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('cbfc6e6521aa8c759c941500d6cb7cea', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1566817688', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('ce061955a791ceb182b21246dd24f65c', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.198 Safari/537.36', '1606116975', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('ce374038983ecee088609bae8c9281af', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', '1582092650', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('cf3801419da6fc89908d57b029be999a', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565789433', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('cfb71d4f090767653dca0fdabe444ebb', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564133931', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('d15181784e689920f08a814244329c4f', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564492536', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('d1f06de8da571fdb91ed378d71a66611', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564393745', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('d1f888b1d33fe0d819ded9cf63717af5', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', '1583949308', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('d1ff4d390f3e5c0cca322859c4f93995', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564492536', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('d25ad0ba6c654e6b47d732154869d91d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564135860', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('d2f729b69553626b272c8ebd9af660a5', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564132728', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('d37dda8747939d096bdef522ae43640c', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '1579194027', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('d3e2bd44341e22282a6a085dc77e695d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564129811', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('d6ab5a1f8ba468b49f6c95e0a431cc7d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36', '1605266752', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('d816aae28c015d1a9ba692ae88681131', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565768642', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('d83102595bc76a4cf868258dbf40023f', '192.168.43.68', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564067830', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('d85f5cb298170deb9a8ebd4ec5942483', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564582599', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('d9c892c5e89f2b78b73543298b85ff61', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564150453', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('da0c6c3ad4b48867f0e0a1bfb45eec67', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36', '1605532551', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('da463651df110f9b18226125a416997a', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564136018', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('da88ac22d82d83585eec507ad72678cf', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '1568874308', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('dad429806c95d75b4f9951ef2347a065', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', '1582008805', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('db5afcb75217afd21562538bdf725cd6', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564133962', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('dcf7cfe71dff8d74c611e7ede98dad02', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564388467', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('de6c9e28bfadaa4b8ac4264031fa2fb7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564133156', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('de836cb2cbda6baea004224b75f16b17', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', '1581936874', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('e0350f39463cd7701a0714a30322796a', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1566830069', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('e0726810d452e043d24b3a885a08445e', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564133931', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('e1e8f1f22e42ae1f818bae078293f5fb', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', '1569404881', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('e266397bf197f9fa1b89dc758afea96a', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565781385', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('e3d8077e54e22b9b6dc14341c88c5fd7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', '1584016846', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('e4cb93694d18356b383347393ca40f4d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1565789476', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('e580acb63ddde012254606ee5831e877', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36', '1619980666', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('e625ecb075a64cdcd5adfae0a0a10cc3', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', '1584006612', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('e6ae8c349ce30b2bc4be3919b6d18dd9', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '1568937444', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('e71deaf012ad6d943105b84b62a820b0', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36', '1580890126', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:3:\"324\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('e816690648a6f805a5397e81baf7cecd', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.72 Safari/537.36', '1618909059', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('e90667b852547561193cdca71449a3d6', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.193 Safari/537.36', '1605595456', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('e948c0ae01ddbee98df58ab8087b6494', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564825164', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('e94fff673d4e1f5b348f76b66208fdfb', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.93 Safari/537.36', '1619884283', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('eba3a24a021622a23afc6aa683dd8b85', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564409810', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('ebb4108f3d76f11957b39ae863d586dd', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1566896294', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('ed994d082f30572c1b59d5d80b2dbbed', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1565077878', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('ede0c57a4eff43735b9903f59dd00db3', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Safari/537.36', '1613561387', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('edf6c7aafac38e675ab24430ecb52c62', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564141184', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('ee4d504cb2a117a96b7aea3ef24ea7be', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564150190', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('ee9fb19d062c43277e5d6909521328dd', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564582481', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('ef7e439ac584290cd6d9e17ff2d026a9', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1565077878', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('f144230c738742e1d4658ca30a44f8a2', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '1568975712', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('f1b70c1696ef7c384ac1c8dade663e6f', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564136890', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('f20555a0978df57eeb4f97536a8dce0e', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36', '1569662700', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('f22549d7e658f27a5bfb5580e837d20c', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36', '1568629233', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('f320fcd029a6ce5d1f8f207098942889', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', '1581936547', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('f76c8a0d8e015739aa992ec89ce4e43d', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1565193160', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('f852162c27aaebd097f38458de422774', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36', '1582928609', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('f853269c544304741c256e28f815d433', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36', '1582006372', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('faf77bd344a9ea5eb5ea58ef98b1a5dc', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564407996', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('fafaf24915506d31466bc71f251a7a56', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1564150189', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('fb18fbb2aac6ce85f3d7e809d8cc4b8e', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1565077511', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('fb6313ef877aacd80eab75eead33ef88', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Safari/537.36', '1613553395', 'a:1:{s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('fbfa083b29799373185c0b913da901c7', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36', '1566469464', 'a:3:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";s:4:\"data\";N;}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('fc946962ad80578beb7401a19228b62a', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.142 Safari/537.36', '1565193160', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('fcd224aa6570fa4b35745961b1772177', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0', '1565632998', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('fe4cbfbdbdcff9e79e85762407e10af4', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36', '1579194009', '');
INSERT INTO sessions (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('ff39baff058e3c47023f32300c9a74d6', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36', '1584015882', 'a:2:{s:9:\"user_data\";s:0:\"\";s:9:\"person_id\";s:2:\"66\";}');


#
# TABLE STRUCTURE FOR: staffs
#

DROP TABLE IF EXISTS staffs;

CREATE TABLE `staffs` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(10) NOT NULL DEFAULT 'user',
  `person_id` int(10) NOT NULL,
  `added_by` int(10) NOT NULL,
  `deleted` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `username` (`username`),
  KEY `person_id` (`person_id`),
  CONSTRAINT `staffs_ibfk_1` FOREIGN KEY (`person_id`) REFERENCES `people` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO staffs (`username`, `password`, `role`, `person_id`, `added_by`, `deleted`) VALUES ('admin', '21232f297a57a5a743894a0e4a801fc3', 'mgmt', '66', '66', '0');
INSERT INTO staffs (`username`, `password`, `role`, `person_id`, `added_by`, `deleted`) VALUES ('Festo', '708f55899bb45390347f528ea08003fe', 'user', '323', '66', '0');
INSERT INTO staffs (`username`, `password`, `role`, `person_id`, `added_by`, `deleted`) VALUES ('dayo1', '8697f252713adc9d5c6a547ba55327f5', 'user', '324', '66', '0');
INSERT INTO staffs (`username`, `password`, `role`, `person_id`, `added_by`, `deleted`) VALUES ('mary2', '1252160b3e8f43f2fe2d23001d5152c8', 'user', '325', '324', '0');


#
# TABLE STRUCTURE FOR: tenants
#

DROP TABLE IF EXISTS tenants;

CREATE TABLE `tenants` (
  `person_id` int(10) NOT NULL,
  `house_id` int(11) DEFAULT NULL,
  `date_moved` int(11) NOT NULL DEFAULT '0',
  `deleted` int(1) NOT NULL DEFAULT '0',
  `added_by` int(5) DEFAULT NULL,
  PRIMARY KEY (`person_id`),
  KEY `person_id` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO tenants (`person_id`, `house_id`, `date_moved`, `deleted`, `added_by`) VALUES ('310', '7', '0', '0', '66');
INSERT INTO tenants (`person_id`, `house_id`, `date_moved`, `deleted`, `added_by`) VALUES ('311', '14', '0', '1', '66');
INSERT INTO tenants (`person_id`, `house_id`, `date_moved`, `deleted`, `added_by`) VALUES ('312', '12', '1623591715', '0', '66');
INSERT INTO tenants (`person_id`, `house_id`, `date_moved`, `deleted`, `added_by`) VALUES ('313', '20', '1577621579', '0', '66');
INSERT INTO tenants (`person_id`, `house_id`, `date_moved`, `deleted`, `added_by`) VALUES ('314', '18', '0', '0', '66');
INSERT INTO tenants (`person_id`, `house_id`, `date_moved`, `deleted`, `added_by`) VALUES ('315', '20', '0', '0', '66');
INSERT INTO tenants (`person_id`, `house_id`, `date_moved`, `deleted`, `added_by`) VALUES ('321', '12', '1566556703', '0', '320');
INSERT INTO tenants (`person_id`, `house_id`, `date_moved`, `deleted`, `added_by`) VALUES ('326', '10', '0', '0', '66');
INSERT INTO tenants (`person_id`, `house_id`, `date_moved`, `deleted`, `added_by`) VALUES ('327', '24', '0', '0', '66');


